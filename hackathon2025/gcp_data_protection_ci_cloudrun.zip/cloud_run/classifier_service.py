
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route("/", methods=["POST"])
def classify():
    data = request.get_json()
    table_id = data.get("table_id")
    policy_tags = {"email": "EMAIL_ADDRESS", "phone": "PHONE_NUMBER"}
    return jsonify({"classified": True, "tags": policy_tags})
