
import base64
import json
from google.cloud import dlp_v2

def dlp_trigger(event, context):
    payload = json.loads(base64.b64decode(event['data']).decode())
    dataset_id = payload['dataset_id']
    table_id = payload['table_id']

    dlp = dlp_v2.DlpServiceClient()
    parent = f"projects/{dlp.project_path(payload['project_id'])}/locations/global"
    table_ref = {
        "project_id": payload['project_id'],
        "dataset_id": dataset_id,
        "table_id": table_id
    }

    inspect_job = {
        "inspect_template_name": f"projects/{payload['project_id']}/locations/global/inspectTemplates/pii-template",
        "storage_config": {
            "big_query_options": {
                "table_reference": table_ref
            }
        },
        "actions": [{
            "save_findings": {
                "output_config": {
                    "table": {
                        "project_id": payload['project_id'],
                        "dataset_id": "dlp_results",
                        "table_id": "dlp_findings"
                    }
                }
            }
        }]
    }

    response = dlp.create_dlp_job(parent=parent, inspect_job=inspect_job)
    print("DLP job started:", response.name)
