
from google.cloud import bigquery

client = bigquery.Client()

dataset_id = "demo_data"
table_id = "customers"

schema = [
    bigquery.SchemaField("customer_id", "STRING"),
    bigquery.SchemaField("full_name", "STRING"),
    bigquery.SchemaField("email", "STRING"),
    bigquery.SchemaField("phone", "STRING"),
    bigquery.SchemaField("credit_card", "STRING"),
    bigquery.SchemaField("dob", "DATE")
]

client.create_dataset(dataset_id, exists_ok=True)
table_ref = f"{client.project}.{dataset_id}.{table_id}"

table = bigquery.Table(table_ref, schema=schema)
table = client.create_table(table, exists_ok=True)

rows = [
    ("001", "Alice Smith", "alice@example.com", "1234567890", "4111111111111111", "1990-01-01"),
    ("002", "Bob Jones", "bob@example.com", "0987654321", "5500000000000004", "1985-05-12")
]

errors = client.insert_rows_json(table, [dict(zip([f.name for f in schema], row)) for row in rows])
print("Errors:", errors)
